import { Test } from 'import-alias';
import { Test2 } from './non-alias';
export { Test3 } from 'import-alias';
await __raw_import__("./non-alias");
