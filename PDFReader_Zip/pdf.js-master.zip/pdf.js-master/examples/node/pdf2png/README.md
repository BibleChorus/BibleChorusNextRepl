## Overview

Example to demonstrate converting a PDF file to a PNG image using the PDF.js library.

## Getting started

Install the dependencies and build the PDF.js library:

    $ npm install
    $ gulp dist-install

Run the example to convert the first page of a PDF file to a PNG image:

    $ cd examples/node/pdf2png
    $ node pdf2png.mjs
